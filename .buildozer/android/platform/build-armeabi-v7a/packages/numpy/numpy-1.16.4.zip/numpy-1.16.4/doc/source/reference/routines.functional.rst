Functional programming
**********************

.. currentmodule:: numpy

.. autosummary::
   :toctree: generated/

   apply_along_axis
   apply_over_axes
   vectorize
   frompyfunc
   piecewise
